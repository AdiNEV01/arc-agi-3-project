# ARC-AGI-3: Report writer handover (25 October 2026)

**Audience:** The teammate writing the joint eight-page RL assignment report, including if they did not implement any code.

**Read in this order:** (1) this page; (2) `CLAIM_LEDGER_AND_ACTION_PLAN.md`; (3) `FIGURE_AND_DATA_CONTRACT.md`; (4) `paper_sections.tex`; (5) the teammates' original PPO PDF and DQN evidence archive.

## Aims and submission rules
- Course: COMS4061A / COMS7071A, ARC-AGI-3: Interactive Reasoning Agents. **Moodle due 27 October 2026, 23:59 SAST.**
- Official **RLC 2026 LaTeX template**, **cover page disabled**, **maximum eight pages of main text** (tables/figures included; references excluded). The paper must stand alone without reading supplemental files. **Our `preview_article.tex` is NOT the official template**; it only lets you preview content. Paste/input `paper_sections.tex` into the real author kit and respect its formatting.
- Same authors/student-number emails, consistent team name across Moodle and both Kaggle tracks. A valid official Kaggle code submission (even zero score) and its timestamp/ID are relevant to leaderboard marks; Paper Track write-up/link and copy also required.
- The report is scored on problem understanding (10), baselines (20), substantive iterative improvements (25), experimental rigour (25), report/reproducibility (10) and leaderboard (10).

## Single research question
To what extent do count-based intrinsic exploration rewards and short-term visual histories improve learning and transfer of DQN- and PPO-based agents in ARC-AGI-3 under disclosed training and evaluation budgets?

**Do not claim an isolated DQN-vs-PPO algorithm effect.** DQN learns click coordinates and uses level-delta task reward; historical PPO chooses click type but samples coordinates uniformly and uses WIN-only task reward. The cross-family comparison is between **complete implementations**, evaluated under a common protocol.

## Research story (in plain English)
1. Interactive ARC games have unknown rules, sparse feedback and actions that depend on the game.
2. Build two learning baselines: value-based DQN and policy-gradient PPO.
3. Both baselines are limited by exploration; test count-based novelty (intrinsic reward) as Improvement 1.
4. A single frame omits recent changes; test a four-frame observation as Improvement 2, plus a **memory-only** ablation to separate individual effects.
5. Compare each algorithm's four variants, 3 independent training seeds, learning-curve checkpoints and shared frozen policy evaluation against random reference. Diagnose failures honestly.

## Actual experiment facts available today
- **DQN 75K pilots only:** baseline V0 seed42 and combined V2 seed42 each trained for 75,000 selected actions, 25K per training game on ls20/ar25/bp35. Training level completions V0=1, V2=0. All **18 learned-policy development evaluations** at ft09/vc33/cd82 × evaluation seeds 0/1/2 gave official local score 0 and 0 levels. Pilot speed (including Drive persistence) V0=221.13 actions/s and V2=182.37 actions/s. A 12-run 450K DQN matrix is **reported started** by the user; do not mark runs complete without verified logs and checkpoint receipts.
- **PPO historical report:** four conditions × 3 training seeds × 6 checkpoints (75K...450K) × four exposed evaluation games dc22/ft09/g50t/ka59. It reports 2 out of 288 checkpoint evaluations completing a level, neither full game win. Its RHAE proxy is **not official ARC-AGI-3 score**. Independently read final PPO checkpoint metadata indicating **503,808** training interactions (the requested 500K was rollout-rounded); official shared evaluation still requires execution and review.
- Both algorithms used ls20/ar25/bp35 for their main training set. PPO also used cd82 for **monitoring/validation** according to its PDF; verify whether cd82 ever contributed gradient updates. cd82, ft09, vc33, dc22, g50t, ka59 are **development exposed**, not genuinely unseen. The whole team **confirmed** sb26, sk48, su15 untouched; preserve until a frozen one-time final test.

## Writer's instructions
- Write **methods, setup, hypotheses, prior work and reporting definitions now**. Only populate final Results, Discussion and Abstract conclusions once the official shared scores are delivered.
- Treat PILOT vs HISTORICAL vs SHARED FINAL as distinct evidence categories. Never pool them or compare proxy scores with official scores.
- For each plot/table, insist on both the finished PDF/PNG/SVG figure and the underlying CSV, exact evaluator config, seed/model/step identifiers and a figure caption.
- One trained checkpoint with three evaluation seeds is **one training seed**, not three independent trained models.
- Citation check: original ARC toolkit/docs, DQN (Mnih et al.), PPO (Schulman et al.), GAE, count-based curiosity, invalid-action masking and SB3. Disclose use of external code and AI as required by Wits policy.

## Draft files
- `paper_sections.tex`: substantive first-pass LaTeX sections plus **explicitly labelled pending result placeholders**.
- `references.bib`: foundational bibliography entries; check these for final paper conventions and versioning.
- `preview_article.tex`: stand-alone *generic article-format* preview only. **NOT submission-compliant**.
- `CLAIM_LEDGER_AND_ACTION_PLAN.md`: verified/pending/blocker list, owners and precise release gates.
- `FIGURE_AND_DATA_CONTRACT.md`: what plots are required, what each should show and what CSVs to request.
- `final_evaluation_rows_TEMPLATE.csv`: headers for one row per actual evaluator run; no invented results.

## Three nonnegotiables
1. Submit working official Kaggle code and record its identifier, timestamp, score and matching paper-track evidence **before Moodle deadline**, not just local toolkit evaluations.
2. Preserve held-out independence: no interim probes or tuning on sb26/sk48/su15.
3. Keep within the real RLC template's eight-page main-content limit. Conference RLC's own general page limit does not override this assignment's *stricter* requirement.

## Source archive inside this ZIP
`Sources/` includes the original assignment brief, PPO author's draft (six pages), verified DQN 75K pilot review, and **historical** 24 October integration audit. The integration audit precedes the later PPO checkpoint uploads and must NOT be treated as current checkpoint inventory. These sources are included for tracing claims, not as final paper content.

## Official RLC source
Open the official RLC 2026 author-kit template at https://www.overleaf.com/read/pyndjmbtgsvj (the official RLJ/RLC 2026 CFP links this Overleaf project). Copy the Overleaf project, disable its cover page per the **course assignment**, then insert `paper_sections.tex`. The included `preview_article.pdf` is a clearly labelled content preview, **not** a compliant submission PDF.
