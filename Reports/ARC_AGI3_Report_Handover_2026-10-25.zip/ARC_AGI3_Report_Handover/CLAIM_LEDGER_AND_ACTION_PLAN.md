# Claim ledger, blockers and controlled completion plan

A writer unfamiliar with the code should copy **only VERIFIED** facts into the final paper. Status dates below are as of 25 Oct 2026 unless marked otherwise. A run **started** is not the same as **completed**.

| ID | Question / requirement | Current evidence | Status | Next evidence / action | Primary owner |
|---|---|---|---|---|---|
| B01 | DQN V0/V1/V2 + history-only implemented | 3K original and 75K extended pilots | VERIFIED implementations; FULL 450K PENDING | Collect 12 full-run logs, checkpoints, source+protocol hashes, completed-action counts | DQN owner |
| B02 | Colab interrupted run genuinely resumes | Work CPU local restore test; pilot CUDA checks reported | PARTIAL | Inspect Drive full-generation receipts, check saved time/step, prove interruption/resume and no duplicate job on reconnect | DQN owner |
| B03 | PPO four conditions × 3 seeds available | 12 `.zip` final model paths enumerated; Work reported metadata 503,808 | CHECK MODEL LOAD / HASHES | Load each via correct SB3 policy and record timesteps, architecture, training seed & file hash | PPO owner |
| B04 | PPO `cd82` usage | PPO draft: 'monitoring during training'; user says 'training' | **AMBIGUOUS** | Inspect PPO train config and gradient-generating environment list. Do not label cd82 gradient-training without proof. It remains development-exposed either way. | PPO owner |
| B05 | Game split leak-free | Team confirmed sb26/sk48/su15 untouched; older config labelled other exposed games heldout | **CAN BE SAFE IF FROZEN** | Freeze final evaluation config; preserve reserved games until one-time final test; keep prior exposed games explicitly labeled development | Task3/eval owner |
| B06 | Same evaluation protocol | Shared evaluator passed integration smoke; 75K DQN dev eval passed scorecard invariants | **READY FOR REVIEW** | Approve click-grid64, legal masks, scorecard version, 1K actions, reset semantics, seed mapping, no time cap and model selection | Task3/eval owner |
| B07 | Fair algorithm comparison | DQN level-delta reward / learned spatial clicks vs PPO WIN-only / random click positions | **LIMITATION TO DISCLOSE** | Compare complete systems under common test; do not claim isolated algorithm superiority. Report 450K DQN vs PPO 503,808 (or verified intermediate PPO around 450K) | Authors |
| B08 | Random reference on identical conditions | Historical Task3 random grid 8x8; 75K DQN random reference with common grid | INCOMPLETE FOR FULL MATRIX | Rerun random reference with **same 64x64 click setup**, evaluation games, seeds/action budgets, official scoring | Task3/eval owner |
| B09 | Official local ARC-AGI-3 metrics | Verified for DQN 75K pilot on dev set; PPO historical RHAE is proxy | FINAL RESULTS PENDING | Export raw shared evaluator per-run scorecards for 4×3 DQN, 4×3 PPO and random; validate official/recomputed score | Eval owner |
| B10 | Independent-seed uncertainty | DQN pilots only seed42; PPO historical train seeds0/1/2 | FINAL DQN SEEDS PENDING | n=3 independent train seeds per config, average eval seeds **within each training seed**, then compute SD/range across three train seeds | Results owner |
| B11 | Learning curves and ablations | Full DQN six milestone checkpoints planned, PPO historical CSV exists | FINAL PENDING | Generate checkpoint-budget curves; 2×2 contrasts for novelty/memory/interaction; annotate train budgets; avoid training-reward vs official-score confusion | Results owner |
| B12 | Representative successes/failures | DQN 75K pilots repeat-click failure, PPO two historical isolated ft09 level completions | PARTIAL | Supply 2–4 exact trajectories/replays with model seed/checkpoint/game/actions and honest descriptions | Eval owner |
| B13 | RLC 2026 8-page PDF | This package provides generic preview sections | NOT FINAL | Create official Overleaf RLC 2026 template, disable cover; insert `paper_sections.tex`, add authors, tables, figures, references; check count <=8 | Writer |
| B14 | Team membership Kaggle ARC-AGI-3 + Paper Track | Not verified here | **URGENT BLOCKER** | Check membership/team name and both tracks; ensure eligible evaluated code submission by Moodle cutoff | Submission owner |
| B15 | Competition & Moodle evidence | No confirmed Kaggle code submission ID/score/timestamp or Paper Track writeup link | **URGENT BLOCKER** | Submit tested notebook, record screenshots/URLs/IDs/timestamps and matching code; package Kaggle-team-name.zip | Submission owner |
| B16 | Contribution disclosure / AI declaration | Names/emails and exact provenance not provided | INCOMPLETE | Attribute PPO SB3 masked PPO + teammates' wrappers; DQN implementation, Task3 adapter; citations, AI-use statement according to university policy | Group |

## Immediate chronological sequence

### Gate 0 — before laptop relocation / whenever Colab is accessible
- Check the active training process **once** and recent verified complete Drive checkpoint. Wi-Fi loss does *not necessarily* terminate remote Colab runtime; do not start a duplicate queue.
- If terminated, reconnect/re-auth Google Drive and use the checked restore entrypoint; verify manifest and action counts.
- Collect unique Drive run folder / receipt filename (not credentials) and share with DQN/eval owners.

### Gate 1 — in parallel with 450K training (now)
- Submission owner verifies both Kaggle tracks and produces an official code-submission smoke attempt if needed. This can prevent a loss of 10 leaderboard marks.
- Eval owner signs off a **frozen shared evaluation YAML**: 3 training vs 6 exposed development vs 3 reserved test games, click grid 64, seed mapping 0/1/2, 1,000 selected-action limit, allowed reset, official score, no wall-clock cap, frozen policy/no learning, zero illegal actions, deterministic checkpoint selection.
- PPO owner resolves `cd82` role, 503,808 exact steps, 450K checkpoint metadata, recent stable checkpoint loads, and any report discrepancies.
- Writer fills Intro/Task/Methods/Setup; report author list and full citations are checked. No final-score claims.
- Results owner implements figure-building pipeline on CSV schema and validates on **explicitly labelled pilot** results, not placeholders passed off as final data.

### Gate 2 — after 450K run verification
- DQN owner exports run-by-run manifest across all 12 runs: variant, seed, selected actions, interactions per game, updates, wall time, checkpoints, SHA256, failures, level/task/intrinsic reward logs and frozen evaluator model compatibility.
- If incomplete models remain, recover from exact verified continuation state. Do not switch protocol or extend to 503,808 while the base matrix is unresolved.

### Gate 3 — shared development evaluation
- Eval owner evaluates all final and scheduled milestone checkpoints on declared **development** games. Both algorithms and random baseline use comparable interface/budget. Record one row per run in CSV and one raw JSON per scorecard.
- Model selection rule, if any, must use development data only; preselect final checkpoints when appropriate. Do not use test results to select hyperparameters, seeds, games, checkpoints or algorithm.
- Results owner aggregates means/SD across **training seeds**, uncertainty limited by n=3. Produce curves and case studies; writer interprets both negative and positive findings.

### Gate 4 — one-time final held-out test
- Team confirms frozen protocol and models; sb26, sk48, su15 previously unexamined as agreed. Run every policy via same official scorer, save full runs including failures, stop tuning afterwards.
- Any post-test analysis uses these scores for reporting only. If later models are changed, no fresh heldout-generalisation claim for repeated tests.

### Gate 5 — packaging and QA by deadline
- Report writer merges figures and results, verifies 8-page main text, discusses confounders, independent seeds, reset semantics, action/memory persistence, failure cases, compute cost, scoring and limitations.
- Submission owner exports working Kaggle notebook and evidence, Paper Track link/write-up, contribution statement, verifies team membership, removes API keys, packages `Kaggle-team-name.zip` and submits Moodle before **27 Oct 2026 23:59 SAST**.
- A second person checks the ZIP from scratch: PDF opens, notebook loads, links work, score evidence matches submitted code and all named team members are credited.

## Stop/go rules
- **STOP** when Drive checkpoint corruption, source/hash mismatch, unexplained scorecard disagreement, illegal-action incidence, protocol drift, game split contamination or non-finite loss occurs; preserve logs, do not conceal failures.
- **GO** on negative or zero task performance if software validity is demonstrated: failure is a valid result, not a reason to change test rules.
- Any changes to training beyond the agreed 450K experiment require a *new protocol ID*, separate files and new interpretation.
