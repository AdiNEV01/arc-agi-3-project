# Figure and data contract for the report writer

**Do not use screenshots of Colab as the final scientific plots.** Every graph must be generated from machine-readable raw experimental evidence; deliver the figure (PDF/SVG plus PNG), source CSV/JSON, analysis script, caption and provenance (game, seed, model, checkpoint, scorer version).

## Plot set, by priority

### Figure 1 — Training/evaluation protocol (small diagram)
- Training (ls20/ar25/bp35, same games across DQN and PPO; DQN deterministic 1:1:1 action allocation; PPO three vector lanes).
- Development exposed (cd82/ft09/vc33/dc22/g50t/ka59) and team-confirmed reserved test (sb26/sk48/su15).
- Render separate arrows training => development => one-time final heldout; show that heldout never influences training or model selection.
- Caption: 'Evaluation splits and permitted information flow. Development-exposed games are not claimed as held-out.'

### Figure 2 — Within-DQN checkpoint learning curves (essential)
- X: selected **training** actions (75K,150K,225K,300K,375K,450K), not Colab CPU time and not evaluation actions.
- Y: official local toolkit score on development games; alternate panel: levels completed. Four curves V0, V1, history-only, V2. Add individual training-seed points/traces (n=3), mean and SD or range. Equal weighting across games.
- Important: one trained model with eval seeds0/1/2 is still ONE trained replicate; first average its evaluation seeds, then aggregate across training seeds.
- Caption must say shared *development* evaluation, 1K actions/game, learned weights frozen, zero training at test time.

### Figure 3 — PPO checkpoint learning curves (essential if space)
- Same conventions with PPO four variants, but **recompute official shared scores**. Historic 288-row proxy 'RHAE' is not the official scorer. Note PPO checkpoint counts must be verified because rollout-rounding affects interaction budgets.
- To save space, combine Figure 2 and 3 in two panels with uniform y-axis scale; do not imply reward/action-space identical.

### Table 1 — Joint methodology and hyperparameters (essential)
- Columns: algorithm, policy/architecture, frame history, count bonus, action head/coordinates, task reward, train games, actions/run, trained seeds, learning schedule, compute.
- DQN: level-completion delta reward, learned x/y click from 4096 indices; PPO: WIN-only reward, 7-way masked actions and random click coordinates. Do NOT describe these as algorithm-only controls.
- Include DQN gamma=.99, batch8, epsilon1->.1 over150K, LR 1e-4, replay20K, target sync250 updates; PPO LR3e-4, GAE gamma=.99 lambda=.95, rollout2048×3, clip=.2, minibatch64, epoch10 (PPO author must verify source).

### Table 2 — Final frozen-policy comparisons (essential)
- Rows: each of eight trained configurations (DQN 4 + PPO 4), random reference. Show budget, mean±SD official score *across independent training seeds*, per-game level completions, win rate, average actions, and compute time. Separate exposed development from confirmed final heldout; if both present clearly label columns.
- Don't average loss functions or curiosity returns across algorithms to compare competence.

### Figure 4 — 2×2 ablation effects (recommended)
- For each family, show novelty effect at no-memory = score(novelty-only) - score(baseline), at memory = score(combined) - score(memory-only); memory analogues; descriptive interaction contrast. Error bars n=3 train seeds; with uniformly zero score state 'no detectable task success', not statistically significant superiority.

### Figure 5 — Representative success/failure cases (recommended, small)
- Screenshot sequence/contact sheet or action traces from actual logged trajectories: game ID, algorithm, configuration, train seed, saved step, eval seed, selection policy, terminal, official score. Good negative case: repeated identical click coordinates across 1K actions at 75K DQN pilot, appropriately labelled *pilot*. Successful PPO historical ft09 level completion cannot substitute for final official heldout evidence.
- No screenshots of hidden game source; only visible permitted observations from toolkit replays.

### Figure 6 — Compute efficiency (if space)
- Two bars/panels: training wall-clock or actions per second per variant and score versus environment interactions. Training and evaluation costs are separate, with CPU/T4 hardware stated. Pilot V0 221.13 actions/s and V2 182.37 are implementation/performance evidence, not learning performance.

## Required raw evaluation row schema
See `final_evaluation_rows_TEMPLATE.csv`. One row represents one actual model checkpoint × evaluation game × evaluation seed. For each record include full score, levels completed, wins, actions, termination, training source and checksum, eval config hash, scorer version, any errors. Empty/failed rows must be retained.

## Publication quality rules
- Vector PDF/SVG preferred in LaTeX; PNG at least 300dpi if raster; labels legible at the final two-column size of the official RLC template. No Excel screenshot or tiny unreadable charts.
- Distinct line dashes/markers as well as colours; legends include algorithm/variant; axes always label *training actions* and *official score* with units/scale; error bars explained in captions.
- Reserve enough space in 8 pages: 1 combined learning-curve figure, 1 methodology table, 1 results table, 1 small failure-case panel typically beats six large isolated figures.
- If a result is unavailable by submission time, mark it missing and explain the actual sample size; **never fill with estimates or pilot values relabelled as final**.
